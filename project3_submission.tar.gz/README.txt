Authors : Joel Puthankalam, Ritvik Durgempudi, Tymon Vu
Written in Python3

Project is fully functional

Instructions to Run

./memSim <file.txt> <frames> <algorithm>
where algorithm is either "FIFO", "LRU", or "OPT"

Uses BACKING_STORE.bin included in zip
Example input file format: addresses.txt


